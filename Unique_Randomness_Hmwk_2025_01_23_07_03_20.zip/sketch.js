let table;
let countries = {};
let flowfield;
let resolution = 20; 
let cols, rows;
let particles = [];
let particleCount = 500; 

function preload() {
  table = loadTable('CSVJan22.csv', 'csv', 'header');
}

function setup() {
  createCanvas(1800, 900);
  cols = floor(width / resolution);
  rows = floor(height / resolution);
  flowfield = new Array(cols * rows);

  for (let r = 0; r < table.getRowCount(); r++) {
    let country = table.getString(r, 'Data Center Location');
    let data = parseFloat(table.getString(r, 'Water Withdrawal Usage (Million Gallons)'));
    countries[country] = {data: data, x: random(width), y: random(height)};
  }
  for (let i = 0; i < particleCount; i++) {
    particles.push(new Particle());
  }
}

function draw() {
 
  for (let i = 0; i < height; i++) {
    let inter = map(i, 0, height, 0, 0.7);
    let c = lerpColor(color(0, 0, 0), color(255, 0, 0), inter);
    stroke(c);
    line(0, i, width, i);
  }

  let yoff = 0;
  for (let y = 0; y < rows; y++) {
    let xoff = 0;
    for (let x = 0; x < cols; x++) {
      let index = x + y * cols;
      let angle = noise(xoff, yoff, frameCount * 0.005) * TWO_PI * 2;
      let v = p5.Vector.fromAngle(angle);
      v.setMag(0.5);
      flowfield[index] = v;
      xoff += 0.1;
    }
    yoff += 0.1;
  }

  // Display and move particles
  particles.forEach(particle => {
    particle.follow(flowfield);
    particle.update();
    particle.display();
    particle.edges();
  });

  textSize(16);
  fill(random (100, 255), 255, 5, (sin(frameCount * 3) + 1) * 128); 
  noStroke();
  Object.keys(countries).forEach(country => {
    let info = countries[country];
    text(nf(info.data, 0, 2), info.x, info.y);
  });
}

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);
    this.maxspeed = 8; 
  }

  update() {
    this.vel.add(this.acc);
    this.vel.limit(this.maxspeed);
    this.pos.add(this.vel);
    this.acc.mult(0);
  }

  applyForce(force) {
    this.acc.add(force);
  }

  follow(flowfield) {
    let x = floor(this.pos.x / resolution);
    let y = floor(this.pos.y / resolution);
    let index = x + y * cols;
    let force = flowfield[index];
    this.applyForce(force);
  }

  display() {
    fill(85, 255, 250, 60); 
    noStroke();
    ellipse(this.pos.x, this.pos.y, 18, 18); 
  }

  edges() {
    if (this.pos.x > width) this.pos.x = 0;
    if (this.pos.x < 0) this.pos.x = width;
    if (this.pos.y > height) this.pos.y = 0;
    if (this.pos.y < 0) this.pos.y = height;
  }
}
 
function mousePressed() {
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}